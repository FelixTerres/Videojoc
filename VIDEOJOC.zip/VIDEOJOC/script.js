let vida = 100;
const pocio = 20;
const coladeFenix = 50;

function mostraVida(){
    console.log("La meva vida és:"+vida);
    if(vida == 0 ){
    console.log("Estàs mort")
    }
}
function atac(){
    let torn = Math.floor(Math.random()*3);
    if(torn == 0){
        atacEnemic("Atac Bàsic");
    
    }else if(torn == 1){
        atacEnemic("Bolla de foc");

    }else if(torn == 2){
        atacEnemic("Àcid sulfúric");
    }
}

function atacEnemic(atac){
    console.log(atac)
    let dany;
    let cremat = false;
    let enverinat = false;
if(vida<=0){
console.log("T'has mort")
console.log("Menja't una cola de Fenix")
dany = 0;

}else if(atac == "Atac Bàsic"){
    dany = 10;


 } else if (atac == "Bolla de foc"){
    dany = 10;
   cremat = 5;
 }if (cremat == false) {
    dany = 15;

 } else if(atac == "Àcid sulfúric"){
    dany = 10;
    enverinat = 8;
     }if (cremat == false) {
        dany = 18;
 } 
    vida -= dany;
    if( vida <= 0){
        vida = 0;
    }
    console.log("Has estat atacat per un enemic:")
    mostraVida();

}

function beurePocio(){
    if(vida == 100){
        console.log("Tens la màxima quantitat de vida")
    }else if(vida ==90){
        vida +=10
        console.log("Has estat curat per una poció");
        mostraVida();
    }else if(vida ==0){
        console.log("Estàs mort, la poció no té efecte")
    }else{
    vida += pocio;
    console.log("T'has begut una poció i has estat curat:");
    mostraVida();
    }
    
}
function revivir(){
   if(vida==0){
    vida += coladeFenix
    console.log("Has revivit");
    mostraVida();
    }else{
    
    console.log("No té efecte, no estàs mort")
    mostraVida();
   }
}

function anticremar(){
cremat = 0
}
function antiàcid(){
    enverinat = 0
}



